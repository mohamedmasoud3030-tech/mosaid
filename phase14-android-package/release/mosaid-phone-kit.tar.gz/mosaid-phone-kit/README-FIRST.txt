MOSAID PHASE 14 PHONE KIT — PRIVATE OWNER USE ONLY

Requirements:
- Android arm64-v8a
- Current official Termux from F-Droid or Termux GitHub releases
- Termux:Boot from the same source/signing family, opened once
- A private Telegram bot token (owner-only) and a model API key
- Default model endpoint: Google Gemini free tier via the OpenAI-compatible API

Run inside Termux after extracting:
  bash phone/install-phone.sh

Free-only tripwire: limits.max_cost_usd is pinned to 0.01 and the runtime has
no cost accounting; any paid model would be stopped by the budget tripwire.
The free tier may use conversations to improve the model. Do not share
secrets or private data in chats. No shared-storage permission is requested.
