@echo off
REM Mosaid launcher for Windows 10. Edit CONFIG below if you moved the folder.
setlocal
set "HERE=%~dp0"
if "%MOSAID_CONFIG%"=="" set "MOSAID_CONFIG=%HERE%config.json"
REM Keep the Go heap small on 4 GB laptops; measured peak is ~16 MB.
if "%GOMEMLIMIT%"=="" set "GOMEMLIMIT=64MiB"
if not exist "%MOSAID_CONFIG%" (
  echo Config not found: %MOSAID_CONFIG%
  echo Copy config.example.json to config.json and put your API key file path in it.
  pause
  exit /b 2
)
"%HERE%mosaid-cli.exe" --config "%MOSAID_CONFIG%" %*
