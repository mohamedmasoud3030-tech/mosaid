PHASE 0 QUALIFICATION KIT — NOT A PRODUCT BUILD

Requirements:
- Android arm64-v8a
- Current official Termux from F-Droid or Termux GitHub releases
- Termux:Boot from the same source/signing family, opened once
- A separate test Telegram bot token and a low-privilege test model API key

Run inside Termux after extracting:
  bash phone/install-phone.sh

No shared-storage permission is requested. Do not place real secrets in this kit.
